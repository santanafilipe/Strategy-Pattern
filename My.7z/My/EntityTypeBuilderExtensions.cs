using System;
using Bs2.Eng.AppCore.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Bs2.Eng.Data.EFCore;

public static class EntityTypeBuilderExtensions
{
    public static EntityTypeBuilder<TEntity> ConfigureMutableEntity<TEntity>(this EntityTypeBuilder<TEntity> builder, Bs2DbOptions dbOptions) where TEntity : MutableEntity
    {
        return builder.ConfigureMutableEntity(dbOptions.GetProvider());
    }

    public static EntityTypeBuilder<TEntity> ConfigureMutableEntity<TEntity>(this EntityTypeBuilder<TEntity> builder, Bs2ProviderOptions providerOptions) where TEntity : MutableEntity
    {
        string name = builder.Metadata.ClrType.Name;
        builder.ToTable(name);
        builder.HasKey((TEntity e) => e.Id).IsClustered(clustered: false).HasName("PK_" + name + "_Id");
        builder.Property((TEntity e) => e.Id).ValueGeneratedNever().IsRequired();
        builder.HasAlternateKey((TEntity e) => e.ChaveSequencial).HasName("AK_" + name + "_ChaveSequencial");
        builder.Property((TEntity e) => e.ChaveSequencial).UseIdentityColumn().ValueGeneratedOnAdd()
            .IsRequired()
            .Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Throw);
        if (providerOptions.Provider == DbProvider.PostgreSQL)
        {
            builder.Property((TEntity e) => e.Version).IsRowVersion().HasColumnName("xmin")
                .HasColumnType("xid")
                .HasConversion((byte[] v) => BitConverter.ToUInt32((ReadOnlySpan<byte>)v), (uint v) => BitConverter.GetBytes(v))
                .IsRequired();
        }
        else
        {
            builder.Property((TEntity e) => e.Version).IsRowVersion().HasColumnType("rowversion")
                .IsRequired();
        }

        builder.Property((TEntity e) => e.CriadoEmUtc).IsRequired();
        builder.Property((TEntity e) => e.AlteradoEmUtc).IsRequired();
        builder.HasIndex((TEntity e) => e.ChaveSequencial).HasDatabaseName("IX_" + name + "_ChaveSequencial").IsUnique()
            .IsClustered();
        return builder;
    }
}