using System;
using System.Threading;
using System.Threading.Tasks;

namespace Bs2.Eng.AppCore.UseCases;

public interface IUnityOfWorkAsyncTransaction : IAsyncDisposable
{
    bool Finished { get; }

    Guid? TransactionId { get; }

    Task CommitAsync(CancellationToken cancellationToken);

    Task RollbackAsync(CancellationToken cancellationToken);
}