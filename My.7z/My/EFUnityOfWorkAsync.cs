using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Bs2.Eng.AppCore.Domain;
using Bs2.Eng.AppCore.UseCases;
using Bs2.Eng.Shared;
using Microsoft.EntityFrameworkCore;

namespace Bs2.Eng.Data.EFCore;

public sealed class EFUnityOfWorkAsync : IUnityOfWorkAsync, IUnityOfWorkBase
{
    private EFUnityOfWorkAsyncTransaction? _currentTransaction;

    public DbContext UnityOfWorkImpl { get; private set; }

    public EFUnityOfWorkAsyncTransaction? CurrentTransaction
    {
        get
        {
            if (_currentTransaction == null || _currentTransaction.Finished)
            {
                return null;
            }

            return _currentTransaction;
        }
    }

    IUnityOfWorkAsyncTransaction? IUnityOfWorkAsync.CurrentTransaction
    {
        get
        {
            throw new NotImplementedException();
        }
    }

    public EFUnityOfWorkAsync(DbContext unityOfworkImpl)
    {
        UnityOfWorkImpl = unityOfworkImpl ?? throw Exceptions.ArgNullEx("unityOfworkImpl");
    }

    public async Task<IUnityOfWorkAsyncTransaction> BeginTransactionAsync(CancellationToken cancellationToken)
    {
        EnsureDoesntHavePendingTransaction();
        return _currentTransaction = new EFUnityOfWorkAsyncTransaction(await UnityOfWorkImpl.Database.BeginTransactionAsync(cancellationToken));
    }

    public async Task<IUnityOfWorkAsyncTransaction> BeginTransactionAsync(IsolationLevel isolation, CancellationToken cancellationToken)
    {
        EnsureDoesntHavePendingTransaction();
        return _currentTransaction = new EFUnityOfWorkAsyncTransaction(await UnityOfWorkImpl.Database.BeginTransactionAsync(isolation, cancellationToken));
    }

    public EFUnityOfWorkAsyncTransaction EnsureCurrentTransaction()
    {
        if (CurrentTransaction == null)
        {
            throw Exceptions.Bs2Ex("Transaction not started.");
        }

        return CurrentTransaction;
    }

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
    {
        return UnityOfWorkImpl.SaveChangesAsync(cancellationToken);
    }

    public async Task<int> CompleteTransactionAsync(CancellationToken cancellationToken)
    {
        int result;
        await using (IUnityOfWorkAsyncTransaction transaction = await BeginTransactionAsync(cancellationToken))
        {
            int affectedRows = await SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            result = affectedRows;
        }

        return result;
    }

    public void EnsureIsAttached<TEntity>(TEntity entity) where TEntity : Entity
    {
        if (entity == null)
        {
            throw Exceptions.ArgNullEx("entity");
        }

        if (UnityOfWorkImpl.Entry(entity).State == EntityState.Detached)
        {
            UnityOfWorkImpl.Attach(entity);
        }
    }

    public void SetModified<TEntity>(TEntity entity) where TEntity : Entity
    {
        if (entity == null)
        {
            throw Exceptions.ArgNullEx("entity");
        }

        EnsureIsAttached(entity);
        UnityOfWorkImpl.Entry(entity).State = EntityState.Modified;
    }

    public bool CheckSameTarget(IEnumerable<IUnityOfWork> others)
    {
        return (others ?? throw Exceptions.ArgNullEx("others")).All(CheckSameTargetInternal);
    }

    public bool CheckSameTarget(params IUnityOfWork[] others)
    {
        return CheckSameTarget((IEnumerable<IUnityOfWork>)(others ?? throw Exceptions.ArgNullEx("others")));
    }

    public void EnsureSameTarget(IEnumerable<IUnityOfWork> others)
    {
        if (others == null)
        {
            throw Exceptions.ArgNullEx("others");
        }

        if (!CheckSameTarget(others))
        {
            throw Exceptions.Bs2Ex("UnityOfWorks with differents targets.");
        }
    }

    public void EnsureSameTarget(params IUnityOfWork[] others)
    {
        EnsureSameTarget((IEnumerable<IUnityOfWork>)others);
    }

    private void EnsureDoesntHavePendingTransaction()
    {
        if (CurrentTransaction != null)
        {
            throw Exceptions.Bs2Ex("Previous transaction not completed.");
        }
    }

    private bool CheckSameTargetInternal(IUnityOfWork other)
    {
        if (other == null)
        {
            throw new ArgumentNullException("other");
        }

        if (this == other)
        {
            return true;
        }

        if (other is EFUnityOfWork eFUnityOfWork)
        {
            return UnityOfWorkImpl == eFUnityOfWork.UnityOfWorkImpl;
        }

        return false;
    }
}