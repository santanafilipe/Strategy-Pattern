namespace Bs2.Eng.Data;

public sealed class SqlServerProviderOptions : ProviderOptions
{
    public override DbProvider Provider => DbProvider.SqlServer;
}

public sealed class PostgreSqlProviderOptions : ProviderOptions
{
    public override DbProvider Provider => DbProvider.PostgreSQL;
}

public abstract class ProviderOptions
{
    public string Prefix { get; set; }

    public abstract DbProvider Provider { get; }

    public string ConnectionString { get; set; }

    public string? MigrationAssemblyName { get; set; }
}