using System;
using Bs2.Eng.AppCore.Domain;
using Bs2.Eng.AppCore.UseCases;
using Bs2.Eng.Shared.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Npgsql.EntityFrameworkCore.PostgreSQL.Infrastructure;

namespace Bs2.Eng.Data.EFCore;

public static class EFServiceCollectionExtensions
{
    private static readonly string MigrationTableName = "__MigrationsHistory";

    public static IServiceCollection AddBs2EfCoreDbContext(this IServiceCollection services, Action<Bs2DbOptions> options = null)
    {
        Bs2DbOptions bs2DbOptions = new Bs2DbOptions();
        Action<Bs2DbOptions> action = options ?? ((Action<Bs2DbOptions>)delegate
        {
        });
        action(bs2DbOptions);
        services.Configure(action);
        if (bs2DbOptions.CurrentProvider == DbProvider.PostgreSQL)
        {
            services.AddPostgreSQLProvider(bs2DbOptions.PostgreSqlProviderOptions);
        }
        else
        {
            services.AddSqlServerProvider(bs2DbOptions.SqlServerProviderOptions);
        }

        services.AddScoped((IServiceProvider factory) => new EFUnityOfWorkAsync(factory.GetRequiredService<Bs2DbContext>()));
        services.AddScoped((Func<IServiceProvider, IUnityOfWorkAsync>)((IServiceProvider factory) => factory.GetRequiredService<EFUnityOfWorkAsync>()));
        return services;
    }

    public static IServiceCollection AddRepositories(this IServiceCollection services)
    {
        services.AddDependencies((Type i) => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IRepository<>), "*Infrastructure.dll");
        return services;
    }

    public static IServiceCollection AddQueries(this IServiceCollection services)
    {
        services.AddDependencies((Type i) => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IQuery<,>), "*Infrastructure.dll").AddDependencies((Type i) => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IQueryPaging<,>), "*Infrastructure.dll");
        return services;
    }

    private static IServiceCollection AddPostgreSQLProvider(this IServiceCollection services, Bs2ProviderOptions providerOptions)
    {
        Bs2ProviderOptions providerOptions2 = providerOptions;
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", isEnabled: true);
        services.AddDbContext<Bs2DbContext>(delegate (DbContextOptionsBuilder options)
        {
            options.UseNpgsql(providerOptions2.ConnectionString, delegate (NpgsqlDbContextOptionsBuilder opts)
            {
                opts.MigrationsAssembly(providerOptions2.MigrationAssemblyName);
                opts.MigrationsHistoryTable(MigrationTableName, providerOptions2.Prefix.Replace(".", ""));
            });
        });
        DbContextOptionsBuilder<Bs2DbContext> dbContextOptionsBuilder = new DbContextOptionsBuilder<Bs2DbContext>().EnableSensitiveDataLogging().UseNpgsql(providerOptions2.ConnectionString, delegate (NpgsqlDbContextOptionsBuilder opts)
        {
            opts.MigrationsAssembly(providerOptions2.MigrationAssemblyName);
            opts.MigrationsHistoryTable(MigrationTableName, providerOptions2.Prefix.Replace(".", ""));
        });
        services.AddSingleton(dbContextOptionsBuilder.Options);
        return services;
    }

    private static IServiceCollection AddSqlServerProvider(this IServiceCollection services, Bs2ProviderOptions providerOptions)
    {
        Bs2ProviderOptions providerOptions2 = providerOptions;
        services.AddDbContext<Bs2DbContext>(delegate (DbContextOptionsBuilder options)
        {
            options.UseSqlServer(providerOptions2.ConnectionString, delegate (SqlServerDbContextOptionsBuilder opts)
            {
                opts.MigrationsAssembly(providerOptions2.MigrationAssemblyName);
                opts.MigrationsHistoryTable(MigrationTableName, providerOptions2.Prefix.Replace(".", ""));
            });
        });
        DbContextOptionsBuilder<Bs2DbContext> dbContextOptionsBuilder = new DbContextOptionsBuilder<Bs2DbContext>().EnableSensitiveDataLogging().UseSqlServer(providerOptions2.ConnectionString, delegate (SqlServerDbContextOptionsBuilder opts)
        {
            opts.MigrationsAssembly(providerOptions2.MigrationAssemblyName);
            opts.MigrationsHistoryTable(MigrationTableName, providerOptions2.Prefix.Replace(".", ""));
        });
        services.AddSingleton(dbContextOptionsBuilder.Options);
        return services;
    }
}