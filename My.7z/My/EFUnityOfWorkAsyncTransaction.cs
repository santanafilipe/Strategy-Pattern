using System;
using System.Threading;
using System.Threading.Tasks;
using Bs2.Eng.AppCore.UseCases;
using Bs2.Eng.Shared;
using Microsoft.EntityFrameworkCore.Storage;

namespace Bs2.Eng.Data.EFCore;

public sealed class EFUnityOfWorkAsyncTransaction : IUnityOfWorkAsyncTransaction, IAsyncDisposable
{
    private readonly IDbContextTransaction _efTransaction;

    public bool Finished { get; private set; }

    public Guid? TransactionId => _efTransaction.TransactionId;

    public EFUnityOfWorkAsyncTransaction(IDbContextTransaction efTransaction)
    {
        _efTransaction = efTransaction;
    }

    private void EnsureTransactionIsHasntFinished()
    {
        if (Finished)
        {
            throw Exceptions.Bs2Ex("Transaction already completed.");
        }
    }

    public async Task CommitAsync(CancellationToken cancellationToken)
    {
        EnsureTransactionIsHasntFinished();
        try
        {
            await _efTransaction.CommitAsync(cancellationToken);
        }
        finally
        {
            Finished = true;
        }
    }

    public async Task RollbackAsync(CancellationToken cancellationToken)
    {
        EnsureTransactionIsHasntFinished();
        try
        {
            await _efTransaction.RollbackAsync(cancellationToken);
        }
        finally
        {
            Finished = true;
        }
    }

    public async ValueTask DisposeAsync()
    {
        try
        {
            await _efTransaction.DisposeAsync();
        }
        finally
        {
            Finished = true;
        }
    }
}