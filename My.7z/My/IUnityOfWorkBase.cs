using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Bs2.Eng.AppCore.Domain;

namespace Bs2.Eng.AppCore.UseCases;

public interface IUnityOfWorkBase
{
    Task<int> SaveChangesAsync(CancellationToken cancellationToken);

    Task<int> CompleteTransactionAsync(CancellationToken cancellationToken);

    void EnsureIsAttached<TEntity>(TEntity entity) where TEntity : Entity;

    void SetModified<TEntity>(TEntity entity) where TEntity : Entity;

    bool CheckSameTarget(IEnumerable<IUnityOfWork> others);

    bool CheckSameTarget(params IUnityOfWork[] others);

    void EnsureSameTarget(IEnumerable<IUnityOfWork> others);

    void EnsureSameTarget(params IUnityOfWork[] others);
}