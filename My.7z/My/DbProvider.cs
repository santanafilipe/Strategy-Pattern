namespace Bs2.Eng.Data;

public enum DbProvider : byte
{
    PostgreSQL = 1,
    SqlServer
}