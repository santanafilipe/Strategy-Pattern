using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace Bs2.Eng.AppCore.UseCases;

public interface IUnityOfWorkAsync : IUnityOfWorkBase
{
    IUnityOfWorkAsyncTransaction CurrentTransaction { get; }

    Task<IUnityOfWorkAsyncTransaction> BeginTransactionAsync(CancellationToken cancellationToken);

    Task<IUnityOfWorkAsyncTransaction> BeginTransactionAsync(IsolationLevel isolation, CancellationToken cancellationToken);
}