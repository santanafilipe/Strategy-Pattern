namespace Bs2.Eng.Data;

public sealed class DbOptions
{
    public DbProvider CurrentProvider { get; set; } = DbProvider.SqlServer;


    public Bs2SqlServerProviderOptions? SqlServerProviderOptions { get; set; }

    public Bs2PostgreSqlProviderOptions? PostgreSqlProviderOptions { get; set; }

    public Bs2ProviderOptions? GetProvider()
    {
        return GetProvider(CurrentProvider);
    }

    public Bs2ProviderOptions? GetProvider(DbProvider dbProvider)
    {
        if (dbProvider == DbProvider.PostgreSQL)
        {
            return PostgreSqlProviderOptions;
        }

        return SqlServerProviderOptions;
    }
}