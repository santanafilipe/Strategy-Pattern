using System;
using System.Linq;
using System.Reflection;
using Bs2.Eng.Shared;
using Bs2.Eng.Timing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Options;

namespace Bs2.Eng.Data.EFCore;

public sealed class Bs2DbContext : DbContext
{
    private readonly IClock _clock;

    private readonly IOptions<Bs2DbOptions> _dbOptions;

    public Bs2DbContext(DbContextOptions<Bs2DbContext> options, IOptions<Bs2DbOptions>? dbOptions, IClock clock)
        : base(options)
    {
        _clock = clock ?? throw Exceptions.ArgNullEx("clock");
        _dbOptions = dbOptions ?? throw Exceptions.ArgNullEx("dbOptions");
        base.SavingChanges += Bs2DbContext_SavingChanges;
    }

    private void Bs2DbContext_SavingChanges(object? sender, SavingChangesEventArgs e)
    {
        foreach (EntityEntry item in from entry in ChangeTracker.Entries()
                                     where entry.Entity.GetType().GetProperty("CriadoEmUtc") != null
                                     select entry)
        {
            if (item.State == EntityState.Added)
            {
                item.Property("CriadoEmUtc").CurrentValue = _clock.UtcNowWithOffset();
            }
            else if (item.State == EntityState.Modified)
            {
                item.Property("CriadoEmUtc").IsModified = false;
            }
        }

        foreach (EntityEntry item2 in from entry in ChangeTracker.Entries()
                                      where entry.Entity.GetType().GetProperty("AlteradoEmUtc") != null
                                      select entry)
        {
            item2.Property("AlteradoEmUtc").CurrentValue = _clock.UtcNowWithOffset();
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        if (!string.IsNullOrEmpty(_dbOptions.Value.GetProvider().Prefix))
        {
            modelBuilder.HasDefaultSchema(_dbOptions.Value.GetProvider().Prefix.Replace(".", ""));
        }

        ApplyConfiguration(modelBuilder);
        modelBuilder.Model.GetEntityTypes().SelectMany((IMutableEntityType e) => e.GetForeignKeys()).ForEach(delegate (IMutableForeignKey foreignKey)
        {
            foreignKey.DeleteBehavior = DeleteBehavior.NoAction;
        });
        (from e in modelBuilder.Model.GetEntityTypes().SelectMany((IMutableEntityType e) => e.GetProperties())
         where e.ClrType == typeof(string)
         select e).ForEach(delegate (IMutableProperty property)
     {
         property.SetIsUnicode(false);
         if (!property.GetMaxLength().HasValue)
         {
             property.SetMaxLength(100);
         }
     });
        base.OnModelCreating(modelBuilder);
    }

    private void ApplyConfiguration(ModelBuilder modelBuilder)
    {
        MethodInfo methodInfo = typeof(ModelBuilder).GetMethods().Single((MethodInfo e) => e.Name == "ApplyConfiguration" && e.ContainsGenericParameters && e.GetParameters().SingleOrDefault()?.ParameterType.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>));
        foreach (Type item in AppDomain.CurrentDomain.GetAssemblies().SelectMany((Assembly a) => from t in a.GetTypes()
                                                                                                 where t.GetInterfaces().Any((Type i) => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>))
                                                                                                 select t))
        {
            Type type = item.GetInterfaces()[0];
            methodInfo.MakeGenericMethod(type.GenericTypeArguments[0]).Invoke(modelBuilder, new object[1] { Activator.CreateInstance(item, _dbOptions) });
        }
    }
}