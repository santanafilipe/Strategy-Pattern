namespace Bs2.Eng.AppCore.Domain;

public abstract class Entity<TId> : Entity
{
    public TId? Id { get; protected set; }

    public override object? UntypedId => Id;
}

public class GuidIdentifiableEntity : Entity<Guid>
{
    public GuidIdentifiableEntity()
    {
        base.Id = Guid.NewGuid();
    }

    public override int GetHashCode()
    {
        return base.Id.GetHashCode();
    }

    public override bool Equals(object? obj)
    {
        if (obj == null)
        {
            return false;
        }

        if (this == obj)
        {
            return true;
        }

        if (!(obj is GuidIdentifiableEntity guidIdentifiableEntity))
        {
            return false;
        }

        if (GetUnproxiedType() != guidIdentifiableEntity.GetUnproxiedType())
        {
            return false;
        }

        if (base.Id == guidIdentifiableEntity.Id)
        {
            return true;
        }

        return false;
    }
}

public abstract class MutableEntity : GuidIdentifiableEntity
{
    public virtual byte[]? Version { get; set; }

    public virtual DateTimeOffset? AlteradoEmUtc { get; set; }
}