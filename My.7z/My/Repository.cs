namespace Bs2.Eng.AppCore.Domain;

public interface IRepository<TEntity> where TEntity : MutableEntity, IAggregateRoot
{
    void Remove(TEntity entity);

    Task AddAsync(TEntity entity, CancellationToken cancellationToken);

    Task<TEntity> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task<IReadOnlyList<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken cancellationToken);
}

public abstract class Repository<TEntity> : EFUnityOfWorkAsyncAttachedRepository, IRepository<TEntity> where TEntity : MutableEntity, IAggregateRoot
{
    protected DbSet<TEntity> Entity { get; }

    protected Bs2Repository(EFUnityOfWorkAsync efUnityOfWork)
        : base(efUnityOfWork)
    {
        Entity = base.EfUnityOfWorkImpl.Set<TEntity>();
    }

    public void Remove(TEntity entity)
    {
        Entity.Remove(entity ?? throw Exceptions.ArgNullEx("entity"));
    }

    public async Task AddAsync(TEntity entity, CancellationToken cancellationToken)
    {
        await Entity.AddAsync(entity ?? throw Exceptions.ArgNullEx("entity"), cancellationToken);
    }

    public async Task<IReadOnlyList<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken cancellationToken)
    {
        return await Entity.Where(predicate).ToListAsync(cancellationToken);
    }

    public async Task<TEntity> GetByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        return await Entity.SingleOrDefaultAsync((TEntity e) => e.Id == id, cancellationToken);
    }
}