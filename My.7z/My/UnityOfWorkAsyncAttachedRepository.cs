namespace Bs2.Eng.Data.EFCore;

public interface IUnityOfWorkAsyncAttachedRepository
{
    IUnityOfWorkAsync UnityOfWork { get; }
}

public class EFUnityOfWorkAsyncAttachedRepository : IUnityOfWorkAsyncAttachedRepository
{
    public IUnityOfWorkAsync UnityOfWork { get; }

    protected DbContext EfUnityOfWorkImpl { get; }

    public EFUnityOfWorkAsyncAttachedRepository(EFUnityOfWorkAsync efUnityOfWork)
    {
        UnityOfWork = efUnityOfWork;
        EfUnityOfWorkImpl = efUnityOfWork.UnityOfWorkImpl;
    }
}

